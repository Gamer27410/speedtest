document.getElementById("startBtn").addEventListener("click", startSpeedTest);

async function startSpeedTest() {
    const downloadSpeed = await measureSpeed("download");
    const uploadSpeed = await measureSpeed("upload");

    document.getElementById("download").textContent = downloadSpeed.toFixed(2);
    document.getElementById("upload").textContent = uploadSpeed.toFixed(2);
}

async function measureSpeed(type) {
    const startTime = Date.now();
    const fileSize = 5 * 1024 * 1024; // 5MB test file (simulated)
    let loaded = 0;
    const progress = document.getElementById("progress");

    // Simulate network request
    const interval = setInterval(() => {
        loaded += Math.random() * 500000; // Random progress
        const percent = Math.min((loaded / fileSize) * 100, 100);
        progress.style.width = `${percent}%`;

        if (loaded >= fileSize) {
            clearInterval(interval);
        }
    }, 100);

    // Fake delay to simulate network
    await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 2000));
    clearInterval(interval);
    progress.style.width = "0%";

    const endTime = Date.now();
    const duration = (endTime - startTime) / 1000; // in seconds
    const bitsLoaded = fileSize * 8; // Convert bytes to bits
    const speedMbps = (bitsLoaded / duration) / 1e6; // Megabits per second

    return speedMbps;
}